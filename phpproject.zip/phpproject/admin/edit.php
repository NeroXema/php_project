<?php 
error_reporting(1);
include('connection.php');
$sql=mysqli_query($conn,"SELECT * FROM product WHERE id='{$_GET['p_id']}'");
$row=mysqli_fetch_array($sql);
extract($_POST); 
if($upd)
{

if($_FILES['p_img']['name'] == null){
	mysqli_query($conn, "UPDATE product SET p_model='$p_model', p_price='$p_price',  p_desc='$p_desc' WHERE id='{$_GET['p_id']}'");
}
else{
	$p_img = $_FILES['p_img']['name'];		
	move_uploaded_file($_FILES['p_img']['tmp_name'],"product_images/$p_img");
	mysqli_query($conn, "UPDATE product SET p_model='$p_model', p_price='$p_price', p_img='$p_img', p_desc='$p_desc' WHERE id='{$_GET['p_id']}'");
}
header('location:view-product.php');

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="../favicon.png">
	<title>ITStore.com</title>
</head>
<body bgcolor="#808080">
<center>
	<form method="POST" enctype="multipart/form-data">
		<table>
			<tr>
				<td>
					<img src="product_images/<?php echo $row['p_img'];?>" width="250px" height="250px"/>
				</td>
				
				<td><input type="file" name="p_img" ></td>
			</tr>
			<!-- <tr>
				<Td>Product Brand</td>
				<td><input type="text" name="p_brand" value="<?php echo $row['p_brands'];?>"></td>
			</tr> -->
		    <tr>
		    	<td>Product Model</td>
		    	<td><input type="text" name="p_model" value="<?php echo $row['p_model'];?>"></td>
		    </tr>
		    <tr>
		    	<Td>Product Price</td>
		    	<td><input type="text" name="p_price" value="<?php echo $row['p_price'];?>"></td>
		    </tr>
		    <tr>
		    	<Td>Product Des</td>
		    	<td>
		    	<textarea name="p_desc" cols="21" rows="10"><?php echo $row['p_desc'];?></textarea></td>
		    </tr>
		    <tr>
		    	<Td colspan="2" align="center">
		    	<input type="submit" value="Update My records" name="upd"/>
		    	</Td>
		    </tr>
		</table>
	</form>
</center>
</body>
</html>