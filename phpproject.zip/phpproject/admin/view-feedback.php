<?php
    error_reporting(1);
	session_start();
    include 'connection.php';
    if(!empty($_SESSION["aid"])){
        $id = $_SESSION["aid"];
        $result = mysqli_query($conn,"SELECT * FROM foradmin WHERE id='$id'");
        $row = mysqli_fetch_assoc($result);
    }
    else{
        header("location:login.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="1.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <link rel="icon" href="../favicon.png">
    <title>Furni.co</title>
</head>
<style>
    body{
        background: url(img/fb.jpg);
        background-size: cover;
        background-repeat: no-repeat;
    }
    h1{
        color: #fff;
        margin-top: 20px;
    }
    table{
        margin-top: 30px;
        border: 1px solid black;
        border-collapse: collapse;
        background: #fff;   
    }
    td{
        background-color: #fefae0;
    }
    table,th,td{
        border: 1px solid gray;
    }
    
</style>
<body>
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="bi bi-list"></i>
        </label>
        <label class="logo">FURNI.</label>
        <ul>
            <li><a href="index.php">profile</a></li>
            <li><a href="insert.php">Add Products</a></li>
            <li><a href="view-product.php">Product</a></li>
            <li><a href="view-order.php">Order</a></li>
            <li><a class="active" href="view-feedback.php">Feedback</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav> 
<center>
    <h1>Feedback From User</h1>
    <table>
        <tr>
            <th width="50px">ID</th>
            <th width="250px">Name</th>
            <th width="300px">Email</th>
            <th width="300px">Message</th>
            <th width="100px">Delete</th>
        </tr>
            <?php
				error_reporting(1);
				include("connection.php");
				$view = "SELECT * FROM feedback";
				$result = mysqli_query($conn, $view);
				while(list($id, $name, $email, $message) = mysqli_fetch_array($result))
				{
            ?>
					<tr align='center'>
					    <td><?php echo "$id"; ?></td>
					    <td><?php echo "$name"; ?></td>
					    <td><?php echo "$email"; ?></td>
					    <td><?php echo "$message"; ?></td>
					    <td><a href='del.php?id=<?php echo "$id"; ?>' onclick="return confirm('Are you sure?')">Delete</a></td>
				    </tr>
                    <tr>
                        <td colspan="10"></td>
                    </tr>
			<?php } ?>
	</table>
</center><br>
</body>
</html>