<?php
    error_reporting(1);
    include 'connection.php';
    if(!empty($_SESSION["aid"])){
        $id = $_SESSION["aid"];
        $result = mysqli_query($conn,"SELECT * FROM foradmin WHERE id='$id'");
        $row = mysqli_fetch_assoc($result);
    }
    else{
        header("location:login.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="1.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <link rel="icon" href="../favicon.png">
    <title>Furni.co</title>
</head>
<style>
    body{
        background: url(img/pd.jpg);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        height: 100vh;
    }
    h1{
        font-size: 50px;
        margin-top: 200px;
    }
</style>
<body>
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="bi bi-list"></i>
        </label>
        <label class="logo">FURNI.</label>
        <ul>
            <li><a class="active" href="index.php">profile</a></li>
            <li><a href="insert.php">Add Products</a></li>
            <li><a href="view-product.php">Product</a></li>
            <li><a href="view-order.php">Order</a></li>
            <li><a href="view-feedback.php">Feedback</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    
    <center>
        <h1>WELCOME BACK ADMIN</h1>
    </center>
</body>
</html>