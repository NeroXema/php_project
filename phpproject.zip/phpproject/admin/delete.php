<?php
	error_reporting(1);
	include("connection.php");
	$del = "DELETE FROM product WHERE id='{$_GET['p_id']}'";
	$result = mysqli_query($conn, $del);
	unlink("product_images/".$_GET['p_img']);
	rmdir("product_images/".$_GET['p_img']);
	echo "<script>alert('Product has been deleted successfully!')</script>";
	echo "<script>window.open('view-product.php','_self')</script>";
?>