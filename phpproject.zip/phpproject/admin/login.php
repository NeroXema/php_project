<?php
    include "connection.php";
    if(!empty($_SESSION['aid'])){
        header("location:index.php");
    }
    if(isset($_POST['submit']))
    {
        $usernameemail = $_POST['usernameemail'];
        $password = $_POST['password'];
        $result = mysqli_query($conn,"SELECT * FROM foradmin WHERE username='$usernameemail' OR email='$usernameemail'");
        $row = mysqli_fetch_assoc($result);

        if(mysqli_num_rows($result) > 0)
        {
            if($password == $row["password"])
            {
                $_SESSION["login"] = TRUE;
                $_SESSION["aid"] = $row["id"];
                
                header("location:index.php");
            }
            echo "<script>alert('Invalid Password!');</script>";
        }
        else{
            echo "<script>alert('Not found Username or Email !');</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ITstore.com</title>
    <link rel="icon" href="../favicon.png">
</head>
<style>
body{
    background: url(img/bg.png);
    background-position: 50 50;
    background-size: cover;
    height: 95vh;
}
h1{
    color: #fff;
}
.a{
    color: #fff;
}
button{
    margin: 0px -40px 0px 60px;
    padding: 10px;
}
.s:hover{
    background: blue;
    color: #fff;
}
.r:hover{
    background: red;
    color: #fff;
}
</style>


<body>
<center>
    <h1>Admin Login Form</h1>
    <form action="" method="POST" autocomplete="off">
        <div class="a">
            <div class="txt_field">
                <label for="usernameemail">Name or Email</label>
                <input type="text" name="usernameemail" id="usernameemail" required>
            </div><br>
            <div class="txt_field">
                <label for="password">Your Password</label>
                <input type="password" name="password" id="password" required>
            </div><br>
            <button type="submit" name="submit" class="s">Login</button>
            <button type="reset" name="submit" class="r">Cancel</button>
        </div>
    </form>
</center>
</body>
</html>