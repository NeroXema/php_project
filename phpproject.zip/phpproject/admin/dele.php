<?php
	error_reporting(1);
	include("connection.php");
	$del = "DELETE FROM `order` WHERE id='{$_GET['id']}'";
	$result = mysqli_query($conn, $del);
	echo "<script>alert('Order has been deleted successfully!')</script>";
	echo "<script>window.open('view-order.php','_self')</script>";
?>