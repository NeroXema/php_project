<?php
    error_reporting(1);
	session_start();
    include 'connection.php';
    if(!empty($_SESSION["aid"])){
        $id = $_SESSION["aid"];
        $result = mysqli_query($conn,"SELECT * FROM foradmin WHERE id='$id'");
        $row = mysqli_fetch_assoc($result);
    }
    else{
        header("location:login.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="1.css">
	<link rel="icon" href="favicon.png">	
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <title>Furni.co</title>
</head>
<style>
    body{
        background: url(img/bg.jpg);
        background-size: cover;
        background-position: center;
        height: 100vh;  
    }
    h1{
        margin-top: 20px;
        color: #fff;
    }
    table{
        border: 1px solid black;
        border-collapse: collapse;
    }
    th{
        background: linear-gradient(30deg, #e9ff70,#ffafcc); 
    }
    td{
        background-color: #fff;
    }
    table,th,td{
        border: 1px solid gray;
    }    
</style>
<body>
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="bi bi-list"></i>
        </label>
        <label class="logo">FURNI.</label>
        <ul>
            <li><a href="index.php">profile</a></li>
            <li><a href="insert.php">Add Products</a></li>
            <li><a class="active" href="view-product.php">Product</a></li>
            <li><a href="view-order.php">Order</a></li>
            <li><a href="view-feedback.php">Feedback</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav> 
<center>
    <h1>Your Product</h1>
    <table>
        <tr>
            <th width="50px">Product id</th>
            <th width="200px">Product model</th>
            <th width="100px">Product price</th>
            <th width="100px">Product image</th>
            <th width="700px">Product description</th>
            <th width="50px">Edit</th>
            <th width="50px">Delete</th>
        </tr>
            <?php
				error_reporting(1);
				include("connection.php");
				$view = "SELECT * FROM product";
				$result = mysqli_query($conn, $view);
				while(list($p_id, $p_model, $p_price, $p_img, $p_desc) = mysqli_fetch_array($result))
				{
            ?>
					<tr align='center'>
					    <td><?php echo "$p_id" ?></td>
					    <td><?php echo "$p_model" ?></td>
					    <td><?php echo "$p_price" ?></td>
					    <td><img src='product_images/<?php echo "$p_img" ?>' width='80px' height='70px'></td>
					    <td><?php echo "$p_desc" ?></td>
					    <td><a href='edit.php?p_id=<?php echo "$p_id" ?>'>Edit</a></td>
					    <td><a href='delete.php?p_id=<?php echo "$p_id" ?>' onclick="return confirm('Are you sure?')">Delete</a></td>
				    </tr>
                    <tr>
                        <td colspan="10"></td>
                    </tr>
			<?php } ?>
	</table>
</center><br>
</body>
</html>