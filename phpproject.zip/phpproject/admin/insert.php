<?php
    error_reporting(1);
	session_start();
    include 'connection.php';
    if(!empty($_SESSION["aid"])){
        $id = $_SESSION["aid"];
        $result = mysqli_query($conn,"SELECT * FROM foradmin WHERE id='$id'");
        $row = mysqli_fetch_assoc($result);
    }
    else{
        header("location:login.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="1.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
	<link rel="icon" href="../favicon.png">
    <title>Furni.co</title>
	<style>
		body{
			background: url(img/bgg.jpg);
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center;
			height: 100vh;
		}
	</style>
</head>

<?php
	error_reporting(1);
	include("connection.php");
	if(isset($_POST['insert']))
	{
		$p_model = $_POST['p_model'];
		$p_price = $_POST['p_price'];
		$p_desc = $_POST['p_desc'];
		$p_img = $_FILES['p_img']['name'];		
		move_uploaded_file($_FILES['p_img']['tmp_name'],"product_images/$p_img");
		$insert_p = "INSERT INTO product VALUES('','$p_model','$p_price','$p_img','$p_desc')";
		$query = mysqli_query($conn,$insert_p);
		echo "<script>alert('Product has been successfully inserted into the database.')</script>";
		echo "<script>window.open('insert.php','_self')</script>";	
	}
?>

<body>
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="bi bi-list"></i>
        </label>
        <label class="logo">FURNI.</label>
        <ul>
            <li><a href="index.php">profile</a></li>
            <li><a class="active" href="insert.php">Add Products</a></li>
            <li><a href="view-product.php">Product</a></li>
            <li><a href="view-order.php">Order</a></li>
            <li><a href="view-feedback.php">Feedback</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

<center>
    <form method="post" action="insert.php" enctype="multipart/form-data">
			<table border="0" cellpadding="10px" align="center" style="font-size:16px; font-weight:bold;">				
				<tr>
					<td>Product Model</td>
					<td><input type="text" name="p_model" required></td>
				</tr>
				<tr>
					<td>Product Price</td>
					<td><input type="text" name="p_price" required></td>
				</tr>
				<tr>
					<td>Product Image</td>
					<td><input type="file" name="p_img" required></td>
				</tr>
				<tr>
					<td>Product Description</td>
					<td><textarea name="p_desc" cols="21" rows="10" required></textarea></td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="insert" value="Insert Product"></td>
				</tr>
			</table>
		  </form>
          </center>
</body>
</html>