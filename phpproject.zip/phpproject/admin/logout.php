<?php
    include 'connection.php';
    unset($_SESSION['aid']);
    header('location:login.php');
?>