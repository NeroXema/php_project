<?php 
	include "connection.php";
	if(!empty($_SESSION["id"])){
        $id = $_SESSION["id"];
        $result = mysqli_query($conn,"SELECT * FROM user_form WHERE id=$id");
        $row = mysqli_fetch_assoc($result);
    }
    else{
        header("location:login.php");
    }

	if(isset($_REQUEST['submit'])){	
		$query = "SELECT * FROM `product_first` ORDER BY id ASC";
		$result = mysqli_query($conn,$query);
		$total = 0;	
		$rows = mysqli_fetch_array($result);
		$name = $_REQUEST['c_fname'];
		$address = $_REQUEST['c_address'];
		$email = $_REQUEST['c_email_address'];
		$phone = $_REQUEST['c_phone'];
		$product =$rows['description'];
		$quantity = $rows['quantity'];
		$price = $rows['price'];
		$order_no =  rand(1,50) ."FUrNi". rand(51,100);
		$sql = "INSERT INTO `order` VALUES ('','$name', '$address', '$email', '$phone', '$product', '$quantity', '$price', '$order_no')";
		if(mysqli_query($conn, $sql)){
			echo "<script>location.href='thankyou.php?order_no=$order_no'</script>";
		}
	}
?>


<!doctype html>
<html lang="en">
<head>
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  	<meta name="author" content="Untree.co">
  	<meta name="description" content="" />
  	<meta name="keywords" content="bootstrap, bootstrap4" />
  	<link rel="shortcut icon" href="favicon.png">
<!-- Bootstrap CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css	rel='stylesheet'">
	<link href="css/tiny-slider.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<title>Furni.co</title>
</head>
<style>
	#cc{
		color: #dc3545;
		text-decoration: none;
	}
</style>
<body>
<!-- Start Header/Navigation -->
	<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">
		<div class="container">
			<a class="navbar-brand" href="#">Furni<span>.</span></a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
			<div class="collapse navbar-collapse" id="navbarsFurni">
				<ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
					<li class="nav-item "><a class="nav-link" href="index.php">Home</a></li>
					<li><a class="nav-link" href="shop.php">Shop</a></li>
					<li><a class="nav-link" href="about.php">About us</a></li>
					<li><a class="nav-link" href="services.php">Services</a></li>
					<li><a class="nav-link" href="blog.php">Blog</a></li>
					<li><a class="nav-link" href="contact.php">Contact us</a></li>
					<li><a class="nav-link" href="home.php"><img src="images/profile.png" alt="profile"></a></li>
				</ul>
			</div>
		</div>
	</nav>
<!-- End Header/Navigation -->

<!-- Start Hero Section -->
	<div class="hero">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-lg-5">
					<div class="intro-excerpt"><h1>Checkout</h1></div>
				</div>
				<div class="col-lg-7">
					
				</div>
			</div>
		</div>
	</div>
<!-- End Hero Section -->

<div class="untree_co-section">
	<div class="container">
		<form action="" method="REQUEST">
		    <div class="row">
		        <div class="col-md-6 mb-5 mb-md-0">
		        	<h2 class="h3 mb-3 text-black">Billing Details</h2>
		        	<div class="p-3 p-lg-5 border bg-white">
		        		<div class="form-group row">
		              		<div class="col-md-12">
		                		<label for="c_fname" class="text-black">Your Name <span class="text-danger">*</span></label>
		                		<input type="text" class="form-control" id="c_fname" name="c_fname" required>
		              		</div>
		            	</div>
		            	<div class="form-group row">
		              		<div class="col-md-12">
		                		<label for="c_address" class="text-black">Address <span class="text-danger">*</span></label>
		                		<input type="text" class="form-control" id="c_address" name="c_address" placeholder="Street address" required>
		              		</div>
		            	</div>
		            	<div class="form-group row mb-5">
		              		<div class="col-md-6">
		                		<label for="c_email_address" class="text-black">Email Address <span class="text-danger">*</span></label>
		                		<input type="email" class="form-control" id="c_email_address" name="c_email_address" required>
							</div>
		              		<div class="col-md-6">
		                		<label for="c_phone" class="text-black">Phone Number <span class="text-danger">*</span></label>
		                		<input type="text" class="form-control" id="c_phone" name="c_phone" placeholder="Phone Number" required>
		              		</div>
		            	</div>
						<table class="table site-block-order-table mb-5">
		                	<thead>
								<th>Image</th>
								<th>Product</th>
								<th>quantity</th>
		                    	<th>Total</th>
		                	</thead>
		                	<tbody>
								<?php 
									$query = "SELECT * FROM `product_first` ORDER BY id ASC";
									$result = mysqli_query($conn,$query);
									$total = 0;
									if(mysqli_num_rows($result) > 0 )
									{
										while($row = mysqli_fetch_array($result))
										{
								?>
		                    	<tr>
									<td><img src="admin/product_images/<?php echo $row['image']; ?>" width="60px" height="60px"></td>
		                    		<td><p><?php echo $row['description']; ?></p></td>
									<td><p><?php echo $row['quantity']; ?></p></td>
		                    		<td><p>Ks <?php echo number_format($row["quantity"]*$row["price"],2); ?></p></td>
		                    	</tr>
								<?php
                					$total = $total + ($row["quantity"]*$row["price"]);
                    					}
                					}
            					?>
		                    	<tr>
		                    		<td class="text-black font-weight-bold"><strong>Total Amount</strong></td>
									<td></td>
									<td></td>
		                    		<td class="text-black font-weight-bold"><strong>Ks <?php echo number_format($total, 2); ?></strong></td>
		                    	</tr>
		                	</tbody>
		            	</table>
						<div class="row mb-5">
                    		<div class="col-md-6 mb-3 mb-md-0">
                    		  <button name="submit" class="btn btn-black btn-sm btn-block">Order Now</button>
                    		</div>
                    		<div class="col-md-6">
                    		  <button class="btn btn-outline-black btn-sm btn-block"><a id="cc" href="del.php">Remove Order</a></button>
                    		</div>
                  		</div>
		          	</div>
		        </div>
		    </div>
		</form>
	</div>
</div>

<!-- Start Footer Section -->
	<footer class="footer-section">
		<div class="container relative">
			<div class="sofa-img">
				<img src="images/sofa.png" alt="Image" class="img-fluid">
			</div>
			<div class="row g-5 mb-5">
				<div class="col-lg-4">
					<div class="mb-4 footer-logo-wrap">
						<a href="#" class="footer-logo">Furni<span>.</span></a>
					</div>
					<p class="mb-4">Donec facilisis quam ut purus rutrum lobortis. Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique. Pellentesque habitant</p>
					<ul class="list-unstyled custom-social">
						<li><a href="#"><span class="fa fa-brands fa-facebook-f"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-twitter"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-instagram"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-linkedin"></span></a></li>
					</ul>
				</div>
				<div class="col-lg-8">
					<div class="row links-wrap">
						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">About us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Blog</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>
						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">Support</a></li>
								<li><a href="#">Knowledge base</a></li>
								<li><a href="#">Live chat</a></li>
							</ul>
						</div>
						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">Jobs</a></li>
								<li><a href="#">Our team</a></li>
								<li><a href="#">Leadership</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">Nordic Chair</a></li>
								<li><a href="#">Kruzo Aero</a></li>
								<li><a href="#">Ergonomic Chair</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>

			<div class="border-top copyright">
				<div class="row pt-4">
					<div class="col-lg-6">
						<p class="mb-2 text-center text-lg-start">Copyright &copy;<script>document.write(new Date().getFullYear());</script>. Pyay Kaung Kyaw &mdash; Designed with love by <a href="https://untree.co">Untree.co</a> Distributed By <a hreff="https://themewagon.com">ThemeWagon</a></p>
					</div>
					<div class="col-lg-6 text-center text-lg-end">
						<ul class="list-unstyled d-inline-flex ms-auto">
							<li class="me-4"><a href="#">Terms &amp; Conditions</a></li>
							<li><a href="#">Privacy Policy</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</footer>
<!-- End Footer Section -->	


<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/tiny-slider.js"></script>
<script src="js/custom.js"></script>
</body>
</html>
