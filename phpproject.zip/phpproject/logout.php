<?php
    include 'connection.php';
    unset($_SESSION['id']);
    $del = "DELETE FROM `product_first`";
	$result = mysqli_query($conn, $del);
    echo "<script>alert('Successfully Logout !!!');</script>";
	echo "<script>window.open('index.php','_self')</script>";
?>