-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 29, 2024 at 02:51 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `itstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_title` varchar(255) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `message` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `message`) VALUES
(1, 'Example', 'example@gmail.com', 'This is good.'),
(2, 'Example', 'example@gmail.com', 'This is testing.');

-- --------------------------------------------------------

--
-- Table structure for table `foradmin`
--

CREATE TABLE IF NOT EXISTS `foradmin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `foradmin`
--

INSERT INTO `foradmin` (`id`, `username`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` int(11) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `quantity` int(250) NOT NULL,
  `price` int(250) NOT NULL,
  `order_no` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `name`, `address`, `email`, `phone`, `product_name`, `quantity`, `price`, `order_no`) VALUES
(1, 'k', 'k', 'k@gmail.com', 1111, '3 Seat Sofa', 1, 300000, '12FUrNi73'),
(2, 'Example', 'Yangon', 'example@gmail.com', 2147483647, 'Special 2 Seat Sofa', 1, 300000, '49FUrNi57'),
(3, 'Example', 'Yangon', 'example@gmail.com', 2147483647, '1 Seat Sofa', 1, 100000, '35FUrNi76');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p_model` varchar(250) NOT NULL,
  `p_price` varchar(200) NOT NULL,
  `p_img` varchar(250) NOT NULL,
  `p_desc` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `p_model`, `p_price`, `p_img`, `p_desc`) VALUES
(29, 'A', '100000', '1.png', '1 Seat Sofa'),
(30, 'A', '100000', '2.png', '1 Seat Sofa'),
(31, 'A', '100000', '3.png', '1 Seat Sofa'),
(32, 'A', '100000', '4.png', '1 Seat Sofa'),
(33, 'B', '200000', '5.png', '2 Seat Sofa'),
(34, 'B', '200000', '6.png', '2 Seat Sofa'),
(35, 'B', '200000', '7.png', '2 Seat Sofa'),
(36, 'B', '200000', '8.png', '2 Seat Sofa'),
(37, 'C', '300000', '9.png', '3 Seat Sofa'),
(38, 'C', '300000', '10.png', '3 Seat Sofa'),
(39, 'C', '300000', '12.png', '3 Seat Sofa'),
(40, 'C', '300000', '16.png', 'Special 2 Seat Sofa');

-- --------------------------------------------------------

--
-- Table structure for table `product_first`
--

CREATE TABLE IF NOT EXISTS `product_first` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL,
  `price` int(200) NOT NULL,
  `quantity` int(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE IF NOT EXISTS `user_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`, `image`) VALUES
(1, 'Example', 'example@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', 'person_2.jpg'),
(2, 'Jack', 'jack@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', ''),
(3, 'mgmg', 'mgmg@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
