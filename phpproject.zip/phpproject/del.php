<?php
	// error_reporting(1);
	include("connection.php");
	$del = "DELETE FROM `product_first`";
	$result = mysqli_query($conn, $del);
	echo "<script>window.open('shop.php','_self')</script>";
?>